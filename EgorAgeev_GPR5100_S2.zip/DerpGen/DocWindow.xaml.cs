﻿using System.Windows;

namespace DerpGen
{
	/// <summary>
	/// Interaction logic for DocWindow.xaml
	/// </summary>
	public partial class DocWindow : Window
	{
		public DocWindow()
		{
			InitializeComponent();
		}
	}
}
